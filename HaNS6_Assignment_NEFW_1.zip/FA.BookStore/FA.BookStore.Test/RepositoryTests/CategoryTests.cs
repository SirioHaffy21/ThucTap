﻿using FA.BookStore.Core.Context;
using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using NUnit.Framework;

namespace FA.BookStore.Test.RepositoryTests
{
    [TestFixture]
    public class CategoryTests
    {
        private static IUnitOfWorks _unitOfWorks;
        private static BookStoreContext _context;
        private static Category _category1;
        private static Category _category2;

        [SetUp]
        public void SetUp()
        {
            _context = new BookStoreContext();
            _unitOfWorks = new UnitOfWorks(_context);

            _category1 = new Category()
            {
                CateName = "Science Fiction",
                Description = "War Movie with best quality"
            };

            _category2 = new Category()
            {
                CateName = "Comedy",
                Description = "10 smiles equals 10 tonic scales"
            };
        }

        [Test]
        public void AddCategory_WhenCalled_Return_True()
        {
            _unitOfWorks.Category.Add(_category1);
            _unitOfWorks.Category.Add(_category2);
            // Act
            int count = _unitOfWorks.SaveChanges();

            // Assert
            Assert.That(count, Is.EqualTo(2));
        }

        [Test]
        public void GetAllCategory_WhenCalled_ReturnListCategoryNotNull()
        {
            var result = _unitOfWorks.Category.GetAll();

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void FindCategory_WhenCalled_ReturnAItemInListCategory()
        {
            var result = _unitOfWorks.Category.Find(item => item.CateName.ToLower().Contains(("Science Fiction").ToLower()));

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void UpdateCategory_WhenCalled_Return_True()
        {
            Category result = _unitOfWorks.Category.Find(item => item.CateId.Equals(1));

            result.CateName = "Hay Ho";

            _unitOfWorks.Category.Update(result);
            int count = _unitOfWorks.SaveChanges();

            Assert.That(count, Is.EqualTo(1));
        }

        [Test]
        public void DeleteCategory_WhenCalled_Return_True()
        {
            _unitOfWorks.Category.DeleteCategory(1);
            int count = _unitOfWorks.SaveChanges();

            Assert.That(count, Is.EqualTo(1));
        }
    }
}