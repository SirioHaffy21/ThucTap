﻿using FA.BookStore.Core.Context;
using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using NUnit.Framework;
using System;

namespace FA.BookStore.Test.RepositoryTests
{
    [TestFixture]
    public class CommentTests
    {
        private static IUnitOfWorks _unitOfWorks;
        private static BookStoreContext _context;
        private static Comment _comment1;
        private static Comment _comment2;

        [SetUp]
        public void SetUp()
        {
            _context = new BookStoreContext();
            _unitOfWorks = new UnitOfWorks(_context);

            _comment1 = new Comment()
            {
                BookId = 2,
                Content = "The Movie should be given Oscar awards",
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            _comment2 = new Comment()
            {
                BookId = 2,
                Content = "The Movie should be given Oscar awards",
                CreatedDate = DateTime.Now,
                IsActive = true
            };
        }

        [Test]
        public void AddComment_WhenCalled_Return_True()
        {
            _unitOfWorks.Comment.Add(_comment1);
            _unitOfWorks.Comment.Add(_comment2);
            // Act
            int count = _unitOfWorks.SaveChanges();
            // Assert
            Assert.That(count, Is.EqualTo(2));
        }

        [Test]
        public void GetAllComment_WhenCalled_ReturnListCommentNotNull()
        {
            var result = _unitOfWorks.Comment.GetAll();

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void FindComment_WhenCalled_ReturnAItemInListComment()
        {
            var result = _unitOfWorks.Comment.Find(item => item.CommentId == 3);

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void GetCommentByBook_WhenCalled_ReturnListCommentByBook()
        {
            var result = _unitOfWorks.Comment.GetCommentByBook(1);

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void UpdateComment_WhenCalled_Return_True()
        {
            var result = _unitOfWorks.Comment.Find(item => item.CommentId.Equals(2));

            _unitOfWorks.Comment.Update(result);
            int count = _unitOfWorks.SaveChanges();

            Assert.That(count, Is.EqualTo(0));
        }

        [Test]
        public void DeleteComment_WhenCalled_Return_True()
        {
            _unitOfWorks.Comment.DeleteComment(1);
            int count = _unitOfWorks.SaveChanges();

            Assert.That(count, Is.EqualTo(0));
        }
    }
}