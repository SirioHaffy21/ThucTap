﻿using FA.BookStore.Core.Context;
using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using NUnit.Framework;
using System;

namespace FA.BookStore.Test.RepositoryTests
{
    [TestFixture]
    public class BookTests
    {
        private static IUnitOfWorks _unitOfWorks;
        private static BookStoreContext _context;
        private static Book _book1;
        private static Book _book2;

        [SetUp]
        public void SetUp()
        {
            _context = new BookStoreContext();
            _unitOfWorks = new UnitOfWorks(_context);

            _book1 = new Book()
            {
                Title = "Fast & Furious",
                CateId = 1,
                AuthorId = 2,
                PubId = 2,
                Summary = "Quickest",
                Price = 12000,
                Quantity = 25,
                CreatedDate = DateTime.Now,
                IsActive = true
            };
            _book2 = new Book()
            {
                Title = "Fast & Furious 2",
                CateId = 1,
                AuthorId = 2,
                PubId = 2,
                Summary = "Quickest",
                Price = 20000,
                Quantity = 24,
                CreatedDate = DateTime.Now,
                IsActive = true
            };
        }

        [Test]
        public void AddBook_WhenCalled_Return_True()
        {
            // Act
            _unitOfWorks.Book.Add(_book1);
            _unitOfWorks.Book.Add(_book2);
            int count = _unitOfWorks.SaveChanges();

            // Assert
            Assert.That(count, Is.EqualTo(2));
        }

        [Test]
        public void GetAllBook_WhenCalled_ReturnListBookNotNull()
        {
            var result = _unitOfWorks.Book.GetAll();

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void FindBook_WhenCalled_ReturnAItemInListBook()
        {
            var result = _unitOfWorks.Book.Find(item => item.Title.ToLower().Contains(("Mr.Bean").ToLower()));

            Assert.That(result, Is.Null);
        }

        [Test]
        public void FindBookByTitle_WhenCalled_ReturnListTitleBookNotNull()
        {
            var result = _unitOfWorks.Book.FindBookByTitle("Fast & Furious");

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void FindBookBySummary_WhenCalled_ReturnListNotNull()
        {
            var result = _unitOfWorks.Book.FindBookBySummary("Good job");

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void GetLatestBook_WhenCalled_ReturnAMaxQuantityItem()
        {
            var result = _unitOfWorks.Book.GetLatestBook(30);

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void GetBooksByMonth_WhenCalled_ReturnListBooksByMonth()
        {
            DateTime dateTime = new DateTime(2021, 12, 21);

            var result = _unitOfWorks.Book.GetBooksByMonth(dateTime);

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void CountBooksForCategory_WhenCalled_ReturnNumberOfCategoryInBookList()
        {
            int countCate = _unitOfWorks.Book.CountBooksForCategory("Comedy");

            Assert.That(countCate, Is.EqualTo(0));
        }

        [Test]
        public void GetBooksByCategory_WhenCalled_ReturnListCategoryOfBookNotNull()
        {
            var result = _unitOfWorks.Book.GetBooksByCategory("Science Fiction");

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void CountBooksForPublisher_WhenCalled_ReturnNumberOfPublisherInBookList()
        {
            int countPub = _unitOfWorks.Book.CountBooksForPublisher("Kim Đồng");

            Assert.That(countPub, Is.EqualTo(0));
        }

        [Test]
        public void GetBooksByPublisher_WhenCalled_ReturnListPublisherOfBookNotNull()
        {
            var result = _unitOfWorks.Book.GetBooksByPublisher("Kim Đồng");

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void UpdateBook_WhenCalled_Return_True()
        {
            Book result = _unitOfWorks.Book.Find(item => item.BookId.Equals(2));

            _unitOfWorks.Book.Update(result);
            int count = _unitOfWorks.SaveChanges();

            Assert.That(count, Is.EqualTo(1));
        }

        [Test]
        public void DeleteBook_WhenCalled_Return_True()
        {
            _unitOfWorks.Book.DeleteBook(1);
            int count = _unitOfWorks.SaveChanges();

            Assert.That(count, Is.EqualTo(0));
        }
    }
}