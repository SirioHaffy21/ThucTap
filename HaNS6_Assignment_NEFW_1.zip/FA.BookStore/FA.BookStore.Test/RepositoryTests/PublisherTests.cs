﻿using FA.BookStore.Core.Context;
using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using NUnit.Framework;

namespace FA.BookStore.Test.RepositoryTests
{
    [TestFixture]
    public class PublisherTests
    {
        private static IUnitOfWorks _unitOfWorks;
        private static BookStoreContext _context;
        private static Publisher _publisher1;
        private static Publisher _publisher2;

        [SetUp]
        public void SetUp()
        {
            _context = new BookStoreContext();
            _unitOfWorks = new UnitOfWorks(_context);

            _publisher1 = new Publisher()
            {
                Name = "Kim Đồng",
                Description = "Nhà xuất bản tuổi thơ"
            };

            _publisher2 = new Publisher()
            {
                Name = "TP.HCM",
                Description = "Nhà xuất bản tương lai"
            };

            _unitOfWorks.Publisher.Add(_publisher1);
            _unitOfWorks.Publisher.Add(_publisher2);
        }

        [Test]
        public void AddPublisher_WhenCalled_Return_True()
        {
            int count = _unitOfWorks.SaveChanges();

            // Assert
            Assert.That(count, Is.EqualTo(2));
        }

        [Test]
        public void GetAllPublisher_WhenCalled_ReturnListPublisherNotNull()
        {
            var result = _unitOfWorks.Publisher.GetAll();

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void FindPublisher_WhenCalled_ReturnAItemInListBook()
        {
            var result = _unitOfWorks.Publisher.Find(item => item.Name.ToLower().Contains(("Kim Đồng").ToLower()));

            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void DeletePublisher_WhenCalled_Return_True()
        {
            _unitOfWorks.Publisher.DeletePublisher(1);
            int count = _unitOfWorks.SaveChanges();

            Assert.That(count, Is.EqualTo(2));
        }

        [Test]
        public void UpdatePublisher_WhenCalled_Return_True()
        {
            Publisher result = _unitOfWorks.Publisher.Find(item => item.PubId.Equals(1));

            _unitOfWorks.Publisher.Update(result);
            int count = _unitOfWorks.SaveChanges();

            Assert.That(count, Is.EqualTo(2));
        }
    }
}