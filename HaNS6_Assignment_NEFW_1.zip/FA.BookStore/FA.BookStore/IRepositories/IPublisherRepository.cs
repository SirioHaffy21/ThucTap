﻿using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;

namespace FA.BookStore.IRepository
{
    public interface IPublisherRepository : IBaseRepository<Publisher>
    {
        void DeletePublisher(int id);
    }
}