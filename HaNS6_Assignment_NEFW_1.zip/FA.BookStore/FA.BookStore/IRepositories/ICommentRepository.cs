﻿using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using System.Collections.Generic;

namespace FA.BookStore.IRepository
{
    public interface ICommentRepository : IBaseRepository<Comment>
    {
        IEnumerable<Comment> GetCommentByBook(int bookId);

        void DeleteComment(int id);
    }
}