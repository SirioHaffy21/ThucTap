﻿using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using System;
using System.Collections.Generic;

namespace FA.BookStore.IRepository
{
    public interface IBookRepository : IBaseRepository<Book>
    {
        void DeleteBook(int id);

        IEnumerable<Book> FindBookByTitle(string title);

        IEnumerable<Book> FindBookBySummary(string summary);

        IEnumerable<Book> GetLatestBook(int size);

        IEnumerable<Book> GetBooksByMonth(DateTime monthYear);

        int CountBooksForCategory(string category);

        IEnumerable<Book> GetBooksByCategory(string category);

        int CountBooksForPublisher(string publisher);

        IEnumerable<Book> GetBooksByPublisher(string publisher);
    }
}