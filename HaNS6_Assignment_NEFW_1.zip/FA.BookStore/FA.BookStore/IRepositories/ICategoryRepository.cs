﻿using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;

namespace FA.BookStore.IRepository
{
    public interface ICategoryRepository : IBaseRepository<Category>
    {
        void DeleteCategory(int id);
    }
}