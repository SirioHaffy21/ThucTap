﻿using FA.BookStore.Core.Context;
using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using FA.BookStore.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FA.BookStore.Repository
{
    public class BookRepository : BaseRepository<Book>, IBookRepository
    {
        private readonly BookStoreContext _context;

        public BookRepository(BookStoreContext context) : base(context)
        {
            _context = context;
        }

        public void DeleteBook(int id)
        {
            if (id <= 0)
            {
                return;
            }

            var entity = _context.Books.FirstOrDefault(item => item.BookId == id);

            if (entity != null)
            {
                _context.Books.Remove(entity);
            }
        }

        public int CountBooksForCategory(string category)
        {
            return _context.Books.Where(item => item.Categories.CateName.ToLower().Contains(category.ToLower())).ToList().Count();
        }

        public int CountBooksForPublisher(string publisher)
        {
            return _context.Books.Where(item => item.Publishers.Name.ToLower().Contains(publisher.ToLower())).ToList().Count();
        }

        public IEnumerable<Book> FindBookBySummary(string summary)
        {
            return _context.Books.Where(item => item.Summary.ToLower().Contains(summary.ToLower())).ToList();
        }

        public IEnumerable<Book> FindBookByTitle(string title)
        {
            return _context.Books.Where(item => item.Title.ToLower().Contains(title.ToLower())).ToList();
        }

        public IEnumerable<Book> GetBooksByCategory(string category)
        {
            return _context.Books.Where(item => item.Categories.CateName.ToLower().Contains(category.ToLower())).ToList();
        }

        public IEnumerable<Book> GetBooksByMonth(DateTime monthYear)
        {
            return _context.Books.Where(item => item.CreatedDate.Month == monthYear.Month).ToList();
        }

        public IEnumerable<Book> GetBooksByPublisher(string publisher)
        {
            return _context.Books.Where(item => item.Publishers.Name.ToLower().Contains(publisher.ToLower())).ToList();
        }

        public IEnumerable<Book> GetLatestBook(int size)
        {
            return _context.Books.OrderBy(item => item.Quantity == size).ToList().Take(1);
        }
    }
}