﻿using FA.BookStore.Core.Context;
using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using FA.BookStore.IRepository;
using System.Linq;

namespace FA.BookStore.Repository
{
    public class CategoryRepository : BaseRepository<Category>, ICategoryRepository
    {
        private readonly BookStoreContext _context;
        private readonly ICategoryRepository _repository;

        public string State { get; set; }

        public CategoryRepository(BookStoreContext context) : base(context)
        {
            _context = context;
        }

        public void DeleteCategory(int id)
        {
            if (id <= 0)
            {
                return;
            }

            var entity = _context.Categories.FirstOrDefault(item => item.CateId == id);

            if (entity != null)
            {
                _context.Categories.Remove(entity);
            }
        }
    }
}