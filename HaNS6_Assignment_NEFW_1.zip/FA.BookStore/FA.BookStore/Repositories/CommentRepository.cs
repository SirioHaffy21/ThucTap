﻿using FA.BookStore.Core.Context;
using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using FA.BookStore.IRepository;
using System.Collections.Generic;
using System.Linq;

namespace FA.BookStore.Repository
{
    public class CommentRepository : BaseRepository<Comment>, ICommentRepository
    {
        private readonly BookStoreContext _context;

        public CommentRepository(BookStoreContext context) : base(context)
        {
            _context = context;
        }

        public void DeleteComment(int id)
        {
            if (id <= 0)
            {
                return;
            }

            var entity = _context.Comments.FirstOrDefault(item => item.CommentId == id);

            if (entity != null)
            {
                _context.Comments.Remove(entity);
            }
        }

        public IEnumerable<Comment> GetCommentByBook(int bookId)
        {
            return _context.Comments.Where(item => item.Books.BookId.Equals(bookId)).ToList();
        }
    }
}