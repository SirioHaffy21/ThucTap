﻿using FA.BookStore.Core.Context;
using FA.BookStore.Core.Models;
using FA.BookStore.Infastructures;
using FA.BookStore.IRepository;
using System.Linq;

namespace FA.BookStore.Repository
{
    public class PublisherRepository : BaseRepository<Publisher>, IPublisherRepository
    {
        private readonly BookStoreContext _context;

        public PublisherRepository(BookStoreContext context) : base(context)
        {
            _context = context;
        }

        public void DeletePublisher(int id)
        {
            if (id <= 0)
            {
                return;
            }

            var entity = _context.Publishers.FirstOrDefault(item => item.PubId == id);

            if (entity != null)
            {
                _context.Publishers.Remove(entity);
            }
        }
    }
}