﻿using FA.BookStore.Core.Context;
using FA.BookStore.IRepository;
using FA.BookStore.Repository;

namespace FA.BookStore.Infastructures
{
    public class UnitOfWorks : IUnitOfWorks
    {
        private readonly BookStoreContext _context;
        private ICategoryRepository _category;
        private IPublisherRepository _publisher;
        private IBookRepository _book;
        private ICommentRepository _comment;

        public UnitOfWorks(BookStoreContext context)
        {
            _context = context;
        }

        public ICategoryRepository Category => _category ?? (_category = new CategoryRepository(_context));

        public IPublisherRepository Publisher => _publisher ?? (_publisher = new PublisherRepository(_context));

        public IBookRepository Book => _book ?? (_book = new BookRepository(_context));

        public ICommentRepository Comment => _comment ?? (_comment = new CommentRepository(_context));

        public BookStoreContext Context => _context;

        public void Dispose()
        {
            _context.Dispose();
        }

        public int SaveChanges()
        {
            return _context.SaveChanges();
        }
    }
}