﻿using FA.BookStore.Core.Context;
using FA.BookStore.IRepository;
using System;

namespace FA.BookStore.Infastructures
{
    public interface IUnitOfWorks : IDisposable
    {
        ICategoryRepository Category { get; }

        IPublisherRepository Publisher { get; }

        IBookRepository Book { get; }

        ICommentRepository Comment { get; }

        BookStoreContext Context { get; }

        int SaveChanges();
    }
}