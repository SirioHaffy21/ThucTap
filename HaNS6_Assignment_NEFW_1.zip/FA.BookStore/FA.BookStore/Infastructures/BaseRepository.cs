﻿using FA.BookStore.Core.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace FA.BookStore.Infastructures
{
    public abstract class BaseRepository<TEntity> : IBaseRepository<TEntity>
        where TEntity : class
    {
        private readonly BookStoreContext _context;
        private readonly DbSet<TEntity> _dbSet;

        public BaseRepository(BookStoreContext context)
        {
            _context = context;
            _dbSet = _context.Set<TEntity>();
        }

        public void Add(TEntity entity)
        {
            _dbSet.Add(entity);
        }

        public TEntity Find(Expression<Func<TEntity, bool>> condition)
        {
            return _dbSet.FirstOrDefault(condition);
        }

        public List<TEntity> GetAll()
        {
            return _dbSet.ToList();
        }

        public void Update(TEntity entity)
        {
            if (entity != null)
            {
                _dbSet.Update(entity);
            }
        }
    }
}