﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace FA.BookStore.Infastructures
{
    public interface IBaseRepository<TEntity>
    {
        void Add(TEntity entity);

        void Update(TEntity entity);

        List<TEntity> GetAll();

        TEntity Find(Expression<Func<TEntity, bool>> condition);
    }
}