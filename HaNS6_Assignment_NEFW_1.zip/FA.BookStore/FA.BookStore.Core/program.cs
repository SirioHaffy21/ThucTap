﻿using System;

namespace FA.BookStore.Core
{
    class program
    {
        static void Main(string []args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
