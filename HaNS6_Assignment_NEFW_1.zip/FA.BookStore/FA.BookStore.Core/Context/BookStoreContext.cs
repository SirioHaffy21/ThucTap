﻿using FA.BookStore.Core.Models;
using Microsoft.EntityFrameworkCore;
using System;

namespace FA.BookStore.Core.Context
{
    public class BookStoreContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }
        public DbSet<Publisher> Publishers { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Comment> Comments { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=DESKTOP-J8U25NA\SQL2014;Database=BookStoreDatabase;user=sa;password=1234567");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Book>()
                .Property(b => b.CreatedDate)
                .HasDefaultValue(DateTime.Now.ToString("dd/MM/yyyy"));

            modelBuilder.Entity<Comment>()
                .Property(cmt => cmt.CreatedDate)
                .HasDefaultValue(DateTime.Now.ToString("dd/MM/yyyy"));
        }
    }
}