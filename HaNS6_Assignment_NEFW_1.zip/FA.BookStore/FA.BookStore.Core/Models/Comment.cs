﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FA.BookStore.Core.Models
{
    public class Comment
    {
        [Key]
        public int CommentId { get; set; }

        public int? BookId { get; set; }

        [ForeignKey("BookId")]
        public Book Books { get; set; }

        [Column(TypeName = "NVARCHAR")]
        [MaxLength(2000)]
        public string Content { get; set; }

        public DateTime CreatedDate { get; set; }

        [DefaultValue("true")]
        public bool IsActive { get; set; }
    }
}