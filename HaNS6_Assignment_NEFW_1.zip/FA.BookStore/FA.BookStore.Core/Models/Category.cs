﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FA.BookStore.Core.Models
{
    public class Category
    {
        [Key]
        public int CateId { get; set; }

        [Column(TypeName = "NVARCHAR")]
        [MaxLength(50)]
        public string CateName { get; set; }

        [Column(TypeName = "NVARCHAR")]
        [MaxLength(500)]
        public string Description { get; set; }

        public ICollection<Book> Books { get; set; }
    }
}