﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FA.BookStore.Core.Models
{
    public class Book
    {
        [Key]
        public int BookId { get; set; }

        [Column(TypeName = "NVARCHAR")]
        [MaxLength(35)]
        public string Title { get; set; }

        public int? CateId { get; set; }

        [ForeignKey("CateId")]
        public Category Categories { get; set; }

        public int? AuthorId { get; set; }

        public int? PubId { get; set; }

        [ForeignKey("PubId")]
        public Publisher Publishers { get; set; }

        [Column(TypeName = "NVARCHAR")]
        [MaxLength(1000)]
        public string Summary { get; set; }

        [Column(TypeName = "NVARCHAR")]
        [MaxLength(300)]
        public string ImgUrl { get; set; }

        public decimal? Price { get; set; }

        public int? Quantity { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }

        [DefaultValue("true")]
        public bool IsActive { get; set; }

        public ICollection<Comment> Comments { get; set; }
    }
}